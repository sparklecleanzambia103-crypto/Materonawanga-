# Lodge Tracker Pro — Deploy to GitHub Pages

## Files in this folder
- index.html  → Main app
- manifest.json → PWA config
- sw.js → Service worker (offline support)
- icon-192.png → App icon
- icon-512.png → App icon (large)

---

## Steps to deploy (do this once)

### 1. Create a GitHub account
Go to https://github.com and sign up (free).

### 2. Create a new repository
- Click the + button → New repository
- Name it: lodge-tracker-pro
- Set it to Public
- Click Create repository

### 3. Upload the files
- Click "uploading an existing file"
- Drag ALL files from this folder into the upload area
- Click "Commit changes"

### 4. Enable GitHub Pages
- Go to Settings → Pages
- Under Source, select: main branch, / (root)
- Click Save

### 5. Your app link will be:
https://YOUR-USERNAME.github.io/lodge-tracker-pro

---

## How lodge owners install it as an app

1. Send them the link above on WhatsApp
2. They open it in Chrome on Android
3. Chrome shows a banner: "Add to Home Screen" — tap it
4. The app installs with the gold icon
5. From now on it opens like a real app — full screen, no browser bar
6. Works completely OFFLINE after first install

---

## Selling tip
When you visit a lodge, open the link on their phone,
let them tap "Add to Home Screen" themselves.
Seeing it install live is what closes the sale.
